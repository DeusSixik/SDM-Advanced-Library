package dev.sixik.sdmal.api.ecs;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.RejectedExecutionException;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.minecraft.world.level.Level;

/**
 * Bounded world-thread command queues. Workers buffer commands privately until successful system commit.
 * Commands submitted while their phase's batch is draining wait for the next tick; required ones are rejected.
 */
public final class WorldContext {
    /**
     * Shared bound for queued commands and all unpublished worker command buffers.
     */
    public static final int COMMAND_CAPACITY = 4096;
    /**
     * Owning manager; contains only a weak reference to the bound Minecraft world.
     */
    private final WorldObjectManager manager;
    /**
     * Serializes outside submissions, phase transitions, capacity reservations and close.
     */
    private final Object lock = new Object();
    /**
     * One owner-drained FIFO per phase; future-tick commands stay queued.
     */
    private final List<ArrayDeque<Command>> queues = List.of(new ArrayDeque<>(), new ArrayDeque<>(), new ArrayDeque<>());
    /**
     * Per-computation buffer, also bound during prepare and apply to propagate required deadlines.
     */
    private final ThreadLocal<Batch> currentJob = new ThreadLocal<>();
    /**
     * Last begun manager tick, initially zero.
     */
    private volatile long tick;
    /**
     * Currently executing phase; null between ticks.
     */
    private volatile TickPhase phase;
    /**
     * Whether the manager has begun a tick whose POST phase is not complete.
     */
    private boolean active;
    /**
     * Whether the current phase accepts commands for this tick.
     */
    private boolean open;
    /**
     * Whether a fixed command batch is currently being drained.
     */
    private boolean flushing;
    /**
     * Ordinal of the last completed phase; -1 at tick start.
     */
    private int completed = -1;
    /**
     * Number of reserved command slots, including unpublished batches.
     */
    private int reserved;
    /**
     * Permanent closed state; all access is guarded by lock.
     */
    private boolean closed;
    /**
     * Deadline inherited by nested submissions from an owner-thread command callback.
     */
    private boolean commandRequired;
    /**
     * Attachment guard inherited by nested submissions from an owner-thread command callback.
     */
    private BooleanSupplier commandGuard;

    /**
     * Creates command queues for one owner-thread manager.
     *
     * @param manager owning manager
     */
    WorldContext(WorldObjectManager manager) {
        this.manager = manager;
    }

    /**
     * Exposes the live Level only to owner-thread preparation/application and legacy component ticks.
     *
     * @return bound live world
     * @throws IllegalStateException on workers, during compute, after close, or for an unbound standalone manager
     */
    public Level level() {
        manager.checkThread();
        Batch batch = currentJob.get();
        if (batch != null && batch.computing)
            throw new IllegalStateException("Live Level access is forbidden during compute");
        if (manager.isClosed()) throw new IllegalStateException("World context is closed");
        return manager.boundWorld();
    }

    /**
     * @return current manager tick sequence; jobs see the sequence captured for their input
     */
    public long tick() {
        Batch batch = currentJob.get();
        return batch == null ? tick : batch.tick;
    }

    /**
     * @return currently executing phase, or null between ticks
     */
    public TickPhase phase() {
        return phase;
    }

    /**
     * @return true when this thread is inside the snapshot-only computation part of a system
     */
    boolean isComputing() {
        Batch batch = currentJob.get();
        return batch != null && batch.computing;
    }

    /**
     * @return total occupied slots, including commands buffered by running jobs
     */
    public int pendingCommands() {
        synchronized (lock) {
            return reserved;
        }
    }

    /**
     * Defers a world mutation to the selected phase, inheriting the current system/component deadline.
     * Capture independently owned or immutable inputs; the callback runs later in the world thread.
     *
     * @param target  destination phase
     * @param command world mutation receiving the live Level only during execution
     * @throws RejectedExecutionException if closed or the shared command capacity is exhausted
     * @throws IllegalStateException      if required work targets a passed phase
     */
    public void enqueue(TickPhase target, Consumer<Level> command) {
        Objects.requireNonNull(command, "command");
        enqueue(target, () -> command.accept(level()));
    }

    /**
     * Defers an owner-thread action without requiring a Minecraft world, including standalone simulations.
     *
     * @param target  destination phase
     * @param command owner-thread operation
     * @throws RejectedExecutionException if closed or full
     * @throws IllegalStateException      if required work targets a passed phase
     */
    public void enqueue(TickPhase target, Runnable command) {
        enqueue(target, command, false);
    }

    /**
     * Defers an action guarded by the exact live object instance, rejecting stale results after UUID reuse.
     *
     * @param target  destination phase
     * @param object  expected live object, not just its UUID
     * @param command operation performed only while the same object remains registered
     */
    public void enqueue(TickPhase target, WorldObject object, Runnable command) {
        Objects.requireNonNull(object, "object");
        Objects.requireNonNull(command, "command");
        enqueue(target, () -> {
            if (!object.isDetached() && manager.get(object.id()).orElse(null) == object) command.run();
        });
    }

    /**
     * Defers an explicitly required owner-thread action; between ticks it is required in the next tick.
     *
     * @param target  destination phase
     * @param command required action
     * @throws IllegalStateException if the current tick has already passed the requested boundary
     */
    public void enqueueRequired(TickPhase target, Runnable command) {
        enqueue(target, command, true);
    }

    /**
     * Validates a phase deadline and reserves capacity before publishing or buffering a command.
     *
     * @param target   destination phase
     * @param action   operation to execute
     * @param required explicit current-tick requirement, combined with inherited restrictions
     */
    private void enqueue(TickPhase target, Runnable action, boolean required) {
        Objects.requireNonNull(target, "target");
        Objects.requireNonNull(action, "command");
        Batch batch = currentJob.get();
        required |= batch != null ? batch.required : manager.legacyMustComplete();
        required |= manager.isOwnerThread() && commandRequired;
        synchronized (lock) {
            if (closed) throw new RejectedExecutionException("World context is closed");
            boolean passed = active && (target.ordinal() <= completed
                    || (phase == target && (!open || flushing)));
            if (required && passed) throw new IllegalStateException("Required command targets passed phase " + target);
            if (reserved >= COMMAND_CAPACITY) throw new RejectedExecutionException("World command capacity exhausted");
            Command command = new Command(active && !passed ? tick : tick + 1, target, action, required,
                    batch != null ? batch.guard : manager.isOwnerThread() ? commandGuard : null);
            reserved++;
            if (batch == null) queues.get(target.ordinal()).addLast(command);
            else batch.commands.add(command);
        }
    }

    /**
     * Begins a tick before PRE; no jobs may outlive the preceding tick.
     *
     * @param sequence manager tick sequence
     */
    void begin(long sequence) {
        manager.checkThread();
        synchronized (lock) {
            if (closed || active) throw new IllegalStateException("World context is closed or already ticking");
            tick = sequence;
            active = true;
            completed = -1;
        }
    }

    /**
     * Opens the next phase in the fixed PRE/NORMAL/POST order.
     *
     * @param next expected next phase
     */
    void startPhase(TickPhase next) {
        synchronized (lock) {
            if (!active || open || next.ordinal() != completed + 1)
                throw new IllegalStateException("Invalid tick phase order: " + next);
            phase = next;
            open = true;
        }
    }

    /**
     * Drains a fixed command batch; errors are reported after the rest of the batch has been attempted.
     */
    void flush() {
        manager.checkThread();
        int remaining;
        ArrayDeque<Command> queue;
        synchronized (lock) {
            if (closed) return;
            if (!open || flushing) throw new IllegalStateException("No open command phase");
            queue = queues.get(phase.ordinal());
            remaining = queue.size();
            flushing = true;
        }
        WorldObjectException errors = null;
        try {
            while (remaining-- > 0) {
                Command command;
                synchronized (lock) {
                    command = queue.pollFirst();
                    if (command == null) break;
                    if (command.tick > tick) {
                        queue.addLast(command);
                        continue;
                    }
                    reserved--;
                }
                boolean previousRequired = commandRequired;
                BooleanSupplier previousGuard = commandGuard;
                commandRequired = command.required;
                commandGuard = command.guard;
                try {
                    if (command.guard == null || command.guard.getAsBoolean()) command.action.run();
                } catch (Throwable failure) {
                    EcsFailures.rethrowFatal(failure);
                    if (errors == null) errors = new WorldObjectException("World commands failed in " + phase);
                    errors.addSuppressed(failure);
                } finally {
                    commandRequired = previousRequired;
                    commandGuard = previousGuard;
                }
            }
        } finally {
            synchronized (lock) {
                flushing = false;
            }
        }
        if (errors != null) throw errors;
    }

    /**
     * Closes the current phase, retaining commands explicitly deferred to a future tick.
     */
    void finishPhase() {
        synchronized (lock) {
            if (closed) return;
            completed = phase.ordinal();
            open = false;
        }
    }

    /**
     * Ends a completed tick, including after recoverable system/command failures.
     */
    void end() {
        synchronized (lock) {
            active = false;
            open = false;
            phase = null;
        }
    }

    /**
     * Binds one job's private command buffer during a callback.
     *
     * @param batch current job's reusable buffer
     */
    void enter(Batch batch) {
        if (currentJob.get() != null) throw new IllegalStateException("Nested ECS system callback");
        currentJob.set(batch);
    }

    /**
     * Removes the current callback binding without allocating a new ThreadLocal entry next time.
     */
    void exit() {
        currentJob.set(null);
    }

    /**
     * Binds an automatic component's private buffer inside its internal system callback.
     *
     * @param batch current component buffer
     * @return enclosing system buffer, possibly null, to restore in finally
     */
    Batch swapBatch(Batch batch) {
        Batch previous = currentJob.get();
        currentJob.set(batch);
        return previous;
    }

    /**
     * @return inherited system deadline while capturing an automatic component batch
     */
    boolean requiresCurrentTick() {
        Batch batch = currentJob.get();
        return batch != null && batch.required;
    }

    /**
     * Publishes a successful system's commands in deterministic owner-thread commit order.
     *
     * @param batch completed job's private commands
     */
    void publish(Batch batch) {
        synchronized (lock) {
            if (closed) {
                discard(batch);
                return;
            }
            for (int index = 0; index < batch.commands.size(); index++) {
                Command command = batch.commands.get(index);
                queues.get(command.phase.ordinal()).addLast(command);
            }
            batch.commands.clear();
        }
    }

    /**
     * Releases commands from an unsuccessful or invalidated job.
     *
     * @param batch buffer whose commands must never be applied
     */
    void discard(Batch batch) {
        synchronized (lock) {
            reserved -= batch.commands.size();
            batch.commands.clear();
        }
    }

    /**
     * Clears queued world references and rejects future submissions; unpublished buffers are released by their jobs.
     */
    void close() {
        manager.checkThread();
        synchronized (lock) {
            closed = true;
            for (var queue : queues) {
                reserved -= queue.size();
                queue.clear();
            }
            end();
        }
    }

    /**
     * An independently scheduled world command.
     *
     * @param tick     earliest manager tick at which the command can run
     * @param phase    requested phase
     * @param action   owner-thread action
     * @param required current-tick deadline inherited by nested command submissions
     * @param guard    optional owner-thread attachment guard, tested immediately before executing the action
     */
    private record Command(long tick, TickPhase phase, Runnable action, boolean required, BooleanSupplier guard) {
    }

    /**
     * Reusable per-system buffer; a phase barrier prevents simultaneous reuse by different ticks.
     */
    static final class Batch {
        /**
         * Unpublished commands, reserved against the world's global capacity.
         */
        final List<Command> commands = new ArrayList<>();
        /**
         * Tick captured for this dispatch.
         */
        long tick;
        /**
         * Whether this dispatch and its commands must finish in this tick.
         */
        boolean required;
        /**
         * Whether a callback is computing, forbidding live-world access even during owner-thread fallback.
         */
        boolean computing;
        /**
         * Optional exact-attachment predicate inherited by queued automatic component commands.
         */
        BooleanSupplier guard;
    }
}
